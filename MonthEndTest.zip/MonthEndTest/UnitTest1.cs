using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace MonthEndTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestGetMonthEnd()
        {
            Assert.AreEqual(31, getMonthEnd("13-Oct-2022"));
            Assert.AreEqual(28, getMonthEnd("01-Feb-2019"));
            Assert.AreEqual(29, getMonthEnd("01-Feb-2020"));
        }

        public int getMonthEnd(string data)
        {
            return DateTime.DaysInMonth(DateTime.Parse(data).Year,DateTime.Parse(data).Month);
        }
    }
}
